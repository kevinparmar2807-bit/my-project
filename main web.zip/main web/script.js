
const books=[ {id:1,title:"Atomic Habits",author:"James Clear",cat:"Self-Help",price:299,emoji:"🌱",rating:5,desc:"A practical guide to building better habits through small, consistent improvements."},
{id:2,title:"The Alchemist",author:"Paulo Coelho",cat:"Fiction",price:199,emoji:"🧭",rating:5,desc:"A timeless story about dreams, purpose and following your own path."},
{id:3,title:"Rich Dad Poor Dad",author:"Robert Kiyosaki",cat:"Business",price:249,emoji:"💰",rating:4,desc:"An introduction to financial thinking, assets, income and personal wealth."},
{id:4,title:"Ikigai",author:"Héctor García",cat:"Self-Help",price:199,emoji:"🌸",rating:4,desc:"Discover ideas about purpose, balance and a meaningful everyday life."},
{id:5,title:"Clean Code",author:"Robert C. Martin",cat:"Technology",price:399,emoji:"💻",rating:5,desc:"Principles and practices for writing readable, maintainable software."},
{id:6,title:"Learning HTML & CSS",author:"BookNest Academy",cat:"Education",price:149,emoji:"🌐",rating:4,desc:"A beginner-friendly introduction to building modern websites."},
{id:7,title:"Deep Work",author:"Cal Newport",cat:"Self-Help",price:279,emoji:"🎯",rating:5,desc:"Strategies for focused work in a distracted digital world."},
{id:8,title:"The Startup Way",author:"Eric Ries",cat:"Business",price:329,emoji:"🚀",rating:4,desc:"Entrepreneurial thinking and innovation for modern organizations."}];



function card(b){return `<article class="card"><div class="cover">${b.emoji}</div><h3>${b.title}</h3><p>${b.author} · ${b.cat}</p><div class="stars">★★★★★</div><div class="card-foot"><b>₹${b.price}</b><button class="add" onclick="add(${b.id})">Add</button></div><a href="book.html?id=${b.id}">View details →</a></article>`}

function render(list,id){let e=document.getElementById(id);if(e)e.innerHTML=list.map(card).join('')}
function booksPage(){let s=document.getElementById('search'),f=document.getElementById('filter');if(!s)return;let q=new URLSearchParams(location.search).get('cat');if(q)f.value=q;function draw(){let t=s.value.toLowerCase(),c=f.value;render(books.filter(b=>(c==='All Categories'||b.cat===c)&&(b.title+' '+b.author).toLowerCase().includes(t)),'books')}s.oninput=draw;f.onchange=draw;draw()}

function details(){let e=document.getElementById('detail');if(!e)return;let id=+new URLSearchParams(location.search).get('id')||1,b=books.find(x=>x.id===id)||books[0];e.innerHTML=`<div class="detail"><div class="cover">${b.emoji}</div><div><small>${b.cat}</small><h1>${b.title}</h1><p>By <b>${b.author}</b></p><p class="page p">A useful digital book available instantly from BookNest.</p><h2>₹${b.price}</h2><button class="btn" onclick="add(${b.id})">Add to Cart</button><a class="btn ghost" href="cart.html">Go to Cart</a></div></div>`}


function loginDemo(e){e.preventDefault();alert("Demo login successful!");location.href="index.html"}
function registerDemo(e){e.preventDefault();alert("Registration successful! Welcome to BookNest.");location.href="login.html"}
function contactDemo(e){e.preventDefault();toast("Message sent successfully!");e.target.reset()}
